Config = {}

-- Where officers can pick up crates
Config.CratePickups = {
    {
        name = "Mission Row Evidence Room",
        coords = vec3(464.09, -993.18, 27.59), -- Example: Mission Row PD
        jobs = { 'police', 'sheriff' }      -- Only these jobs can see this pickup
    },
    {
        name = "BCSO HARMONY EVIDENCE",
        coords = vec3(474.07, 2664.07, 39.52),
        jobs = { 'bcso' }
    }
}

Config.IncineratorCoords = vec3(3561.78, 3670.68, 28.12)
Config.Reward = { min = 5000, max = 10000 }
Config.ItemName = 'evidence_crate'
