fx_version 'cerulean'
game 'gta5'

shared_scripts {
    '@ox_lib/init.lua',
    'shared.lua' -- THIS MUST BE BEFORE CLIENT/SERVER
}

author 'lowkey'


client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}