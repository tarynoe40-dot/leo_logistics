local cratesToGive = 1 -- CHANGE THIS to however many you want them to get

RegisterNetEvent('crate_heist:server:requestCrate', function()
    local src = source
    local player = exports.qbx_core:GetPlayer(src)
    
    if not player then return end

    -- Check if they can carry the amount specified
    if exports.ox_inventory:CanCarryItem(src, Config.ItemName, cratesToGive) then
        
        -- Add the items
        exports.ox_inventory:AddItem(src, Config.ItemName, cratesToGive)
        
        TriggerClientEvent('ox_lib:notify', src, {
            title = 'Evidence Secured',
            description = 'You picked up ' .. cratesToGive .. ' evidence crate(s).',
            type = 'success'
        })
    else
        TriggerClientEvent('ox_lib:notify', src, {
            title = 'Too Heavy',
            description = 'You cannot carry that much evidence!',
            type = 'error'
        })
    end
end)

RegisterNetEvent('crate_heist:server:complete', function()
    local src = source
    local player = exports.qbx_core:GetPlayer(src)
    
    -- This checks for ALL crates in their inventory and burns them all for a payout
    local count = exports.ox_inventory:Search(src, 'count', Config.ItemName)
    
    if count > 0 then
        exports.ox_inventory:RemoveItem(src, Config.ItemName, count)
        
        -- Payout per crate
        local totalReward = 0
        for i = 1, count do
            totalReward = totalReward + math.random(Config.Reward.min, Config.Reward.max)
        end
        
        player.Functions.AddMoney('cash', totalReward, "Burned Evidence")
        
        TriggerClientEvent('ox_lib:notify', src, {
            title = 'Evidence Destroyed',
            description = 'You burned ' .. count .. ' crates for $' .. totalReward,
            type = 'success'
        })
    end
end)