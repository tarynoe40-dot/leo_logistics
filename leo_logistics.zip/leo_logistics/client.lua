-- ==========================================
-- CLEAN INVENTORY-ONLY CLIENT
-- ==========================================

-- 1. Monitor for Death (Simply notify if they drop it mentally)
CreateThread(function()
    while true do
        -- We don't need DropCrate() anymore because there's no physical object
        -- But we can notify the player they "lost focus" if they go down
        if (LocalPlayer.state.isDead or LocalPlayer.state.isDowned) then
            if exports.ox_inventory:Search('count', Config.ItemName) > 0 then
                -- Optional: You could trigger a server event here to remove the item on death
                -- TriggerServerEvent('crate_heist:server:removeOnDeath')
            end
        end
        Wait(1000)
    end
end)

-- 2. Create the Pickup Points
for i, pickup in ipairs(Config.CratePickups) do
    exports.ox_target:addSphereZone({
        name = 'evidence_pickup_' .. i,
        coords = pickup.coords,
        radius = 2.0,
        debugPoly = false, -- Turn this to false once you're happy with the spot
        options = {
            {
                label = 'Retrieve ' .. pickup.name,
                icon = 'box-archive',
                onSelect = function()
                    if lib.progressBar({
                        duration = 3000,
                        label = 'Retrieving Evidence...',
                        useWhileDead = false,
                        canCancel = true,
                        disable = { move = true }
                    }) then
                        -- ONLY triggers the item addition, NO prop code
                        TriggerServerEvent('crate_heist:server:requestCrate')
                    end
                end
            }
        }
    })
end

-- Interaction at the Incinerator
exports.ox_target:addSphereZone({
    name = 'humane_incinerator',
    coords = Config.IncineratorCoords,
    radius = 2.0,
    debugPoly = false,
    options = {
        {
            label = 'Incinerate Evidence',
            icon = 'fire',
            onSelect = function()
                local count = exports.ox_inventory:Search('count', Config.ItemName)
                if count > 0 then
                    local ped = cache.ped
                    local animDict = "amb@world_human_welding@male@base"
                    local propModel = `prop_weld_torch`
                    local ptfxDict = "core"
                    local ptfxName = "ent_dst_gen_fire" -- This creates the spark effect

                    -- 1. Load everything into the game's memory
                    lib.requestAnimDict(animDict)
                    lib.requestModel(propModel)
                    lib.requestNamedPtfxAsset(ptfxDict)

                    -- 2. Spawn the welder tool and stick it in your hand
                    local torch = CreateObject(propModel, 0, 0, 0, true, true, true)
                    AttachEntityToEntity(torch, ped, GetPedBoneIndex(ped, 28422), 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, true, true, false, true, 1, true)
                    
                    -- 3. Start the welding animation and the sparks
                    TaskPlayAnim(ped, animDict, "base", 8.0, -8.0, -1, 1, 0, false, false, false)
                    UseParticleFxAssetNextCall(ptfxDict)
                    local effect = StartNetworkedParticleFxLoopedOnEntity(ptfxName, torch, 0.0, 0.1, 0.0, 0.0, 0.0, 0.0, 1.0, false, false, false)

                    -- 4. The 5-second progress bar
                    if lib.progressBar({
                        duration = 5000,
                        label = 'Welding Incinerator Door Shut...',
                        useWhileDead = false,
                        canCancel = true,
                        disable = { move = true, car = true, combat = true }
                    }) then
                        -- Cleanup after success
                        StopParticleFxLooped(effect, 0)
                        DeleteEntity(torch)
                        ClearPedTasks(ped)
                        TriggerServerEvent('crate_heist:server:complete')
                    else
                        -- Cleanup if you cancel
                        StopParticleFxLooped(effect, 0)
                        DeleteEntity(torch)
                        ClearPedTasks(ped)
                    end
                else
                    exports.qbx_core:Notify("You don't have any evidence!", "error")
                end
            end
        }
    }
})